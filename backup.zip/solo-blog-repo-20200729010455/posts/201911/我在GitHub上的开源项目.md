title: 我在 GitHub 上的开源项目
date: '2019-11-19 11:34:58'
updated: '2019-11-19 11:34:58'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [make-a-little-progress-every-day](https://github.com/ylsislove/make-a-little-progress-every-day) <kbd title="主要编程语言">TeX</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/make-a-little-progress-every-day/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/ylsislove/make-a-little-progress-every-day/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/ylsislove/make-a-little-progress-every-day/network/members "分叉数")</span>

学无止境，督促自己学习。每天进步一点点，水滴石穿-贵在坚持。留住时间的最好方式不就是把生活记录下来吗 😏



---

### 2. [solo-blog](https://github.com/ylsislove/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://localhost`](http://localhost "项目主页")</span>

✍️ yain 的梦境 - 码字、听歌、周游世界



---

### 3. [image-home](https://github.com/ylsislove/image-home) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/image-home/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/image-home/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/image-home/network/members "分叉数")</span>

我的github图床~



---

### 4. [Resource-monitoring-interface](https://github.com/ylsislove/Resource-monitoring-interface) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Resource-monitoring-interface/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Resource-monitoring-interface/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Resource-monitoring-interface/network/members "分叉数")</span>

服务器资源监控界面，flask + mysql + G2搭建



---

### 5. [BaggageCalculator](https://github.com/ylsislove/BaggageCalculator) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/BaggageCalculator/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/BaggageCalculator/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/BaggageCalculator/network/members "分叉数")</span>

国航行李计算器，软测实习题目。jenkins + webpack + jest搭建



---

### 6. [Urban-Perception-Assessment-Based-on-CNN](https://github.com/ylsislove/Urban-Perception-Assessment-Based-on-CNN) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Urban-Perception-Assessment-Based-on-CNN/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Urban-Perception-Assessment-Based-on-CNN/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Urban-Perception-Assessment-Based-on-CNN/network/members "分叉数")</span>

基于卷积神经网络的城市感知评估



---

### 7. [Chinese-ChatBot](https://github.com/ylsislove/Chinese-ChatBot) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Chinese-ChatBot/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Chinese-ChatBot/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Chinese-ChatBot/network/members "分叉数")</span>

中文聊天机器人



---

### 8. [Teacher-Info-System](https://github.com/ylsislove/Teacher-Info-System) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Teacher-Info-System/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Teacher-Info-System/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Teacher-Info-System/network/members "分叉数")</span>

用jsp和servlet实现的教师信息管理系统



---

### 9. [HPSC-SteadyStateHeatConduction-OpenMP](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP) <kbd title="主要编程语言">Fortran</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP/network/members "分叉数")</span>

高性能计算课程设计，使用Jacobi，Gauss-Seidel，SOR算法和OpenMP解决稳态热传导问题



---

### 10. [StepCounter-APP](https://github.com/ylsislove/StepCounter-APP) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/StepCounter-APP/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/StepCounter-APP/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/StepCounter-APP/network/members "分叉数")</span>

移动计算技术课程设计，基于安卓加速度传感器的计步小程序

