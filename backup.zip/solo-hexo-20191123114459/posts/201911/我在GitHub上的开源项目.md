title: 我在 GitHub 上的开源项目
date: '2019-11-19 11:34:58'
updated: '2019-11-19 11:34:58'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [Teacher-Info-System](https://github.com/ylsislove/Teacher-Info-System) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ylsislove/Teacher-Info-System/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ylsislove/Teacher-Info-System/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/ylsislove/Teacher-Info-System/network/members "分叉数")</span>

教师信息管理系统



---

### 2. [Teacher_Info_Management](https://github.com/ylsislove/Teacher_Info_Management) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Teacher_Info_Management/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Teacher_Info_Management/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Teacher_Info_Management/network/members "分叉数")</span>

用jsp和servlet实现的教师信息管理系统



---

### 3. [HPSC-SteadyStateHeatConduction-OpenMP](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP) <kbd title="主要编程语言">Fortran</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/HPSC-SteadyStateHeatConduction-OpenMP/network/members "分叉数")</span>

高性能计算课程设计，使用Jacobi，Gauss-Seidel，SOR算法和OpenMP解决稳态热传导问题



---

### 4. [StepCounter-APP](https://github.com/ylsislove/StepCounter-APP) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/StepCounter-APP/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/StepCounter-APP/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/StepCounter-APP/network/members "分叉数")</span>

移动计算技术课程设计，基于安卓加速度传感器的计步小程序



---

### 5. [Chat](https://github.com/ylsislove/Chat) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Chat/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Chat/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Chat/network/members "分叉数")</span>

移动计算第二次实习-Android项目-小宇聊天室



---

### 6. [Web-Service-Rest-Soap](https://github.com/ylsislove/Web-Service-Rest-Soap) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/Web-Service-Rest-Soap/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/Web-Service-Rest-Soap/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/Web-Service-Rest-Soap/network/members "分叉数")</span>

SA第三次上机实习，基于RESR和SOAP风格的Web Service服务



---

### 7. [three-layer-stock](https://github.com/ylsislove/three-layer-stock) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/three-layer-stock/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/three-layer-stock/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/three-layer-stock/network/members "分叉数")</span>

SA第二次实习



---

### 8. [drools-demo](https://github.com/ylsislove/drools-demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/drools-demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/drools-demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/drools-demo/network/members "分叉数")</span>

软件体系结构与分析课后作业-基于规则引擎的专家系统Demo



---

### 9. [MQ](https://github.com/ylsislove/MQ) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/MQ/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/MQ/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/MQ/network/members "分叉数")</span>

软件体系结构设计与分析第一次实习



---

### 10. [challengeMatch](https://github.com/ylsislove/challengeMatch) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ylsislove/challengeMatch/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ylsislove/challengeMatch/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ylsislove/challengeMatch/network/members "分叉数")</span>

2019年韩国FIRA无人机挑战赛

